const navItems = document.querySelectorAll('.nav-item');
const views = document.querySelectorAll('.view');
const pageTitle = document.getElementById('pageTitle');
const titles = {home:'Phone dashboard',dialer:'Dialer',messages:'Messages',contacts:'Contacts',history:'Call history',admin:'Administration'};
function switchView(id){
  navItems.forEach(n=>n.classList.toggle('active',n.dataset.view===id));
  views.forEach(v=>v.classList.toggle('active-view',v.id===id));
  pageTitle.textContent=titles[id]||'Call App';
  window.scrollTo({top:0,behavior:'smooth'});
}
navItems.forEach(n=>n.addEventListener('click',()=>switchView(n.dataset.view)));
document.querySelectorAll('[data-jump]').forEach(b=>b.addEventListener('click',()=>switchView(b.dataset.jump)));

async function postForm(url, data){
  const body = new URLSearchParams(data);
  const res = await fetch(url,{method:'POST',headers:{'X-CSRF-Token':window.APP.csrf,'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body});
  let json={ok:false,message:'Unexpected server response.'};
  try{ json=await res.json(); }catch(e){}
  if(!res.ok && !json.message) json.message='Request failed.';
  return json;
}
function escapeHtml(s=''){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function toast(message,type='success'){
  const el=document.createElement('div');el.className=`toast ${type}`;el.textContent=message;document.body.appendChild(el);
  requestAnimationFrame(()=>el.classList.add('show'));setTimeout(()=>{el.classList.remove('show');setTimeout(()=>el.remove(),250)},2800);
}

let dial=''; const dialDisplay=document.getElementById('dialNumber');
function renderDial(){if(dialDisplay)dialDisplay.textContent=dial||'Enter number';}
document.querySelectorAll('[data-digit]').forEach(btn=>btn.addEventListener('click',()=>{if(dial.length<30){dial+=btn.dataset.digit;renderDial();}}));
document.getElementById('backspace')?.addEventListener('click',()=>{dial=dial.slice(0,-1);renderDial();});
document.getElementById('clearDial')?.addEventListener('click',()=>{dial='';renderDial();});

const callModal=document.getElementById('callModal'); const callingNumber=document.getElementById('callingNumber');
let callStartedAt=0; let activeCallNumber=''; let activeCallName='';
function openCall(number,name=''){
  number=(number||'').trim(); if(!number){toast('Enter a phone number first.','error');return;}
  activeCallNumber=number;activeCallName=name;callStartedAt=Date.now();callingNumber.textContent=number;callModal.classList.remove('hidden');
}
async function closeCall(save=true){
  if(callModal.classList.contains('hidden')) return;
  callModal.classList.add('hidden');
  if(save && activeCallNumber){
    const duration=Math.max(1,Math.round((Date.now()-callStartedAt)/1000));
    const r=await postForm('api/log_call.php',{phone_number:activeCallNumber,contact_name:activeCallName,duration_seconds:duration});
    toast(r.message,r.ok?'success':'error');
  }
  activeCallNumber='';activeCallName='';
}
document.getElementById('callBtn')?.addEventListener('click',()=>openCall(dial));
document.addEventListener('click',e=>{
  const btn=e.target.closest('[data-call-number]'); if(btn){e.preventDefault();openCall(btn.dataset.callNumber,btn.dataset.callName||'');}
});
document.getElementById('closeCall')?.addEventListener('click',()=>closeCall(true));
document.getElementById('endCall')?.addEventListener('click',()=>closeCall(true));
callModal?.addEventListener('click',e=>{if(e.target===callModal)closeCall(true);});

const formModal=document.getElementById('formModal'); const formModalBody=document.getElementById('formModalBody');
function openForm(html){formModalBody.innerHTML=html;formModal.classList.remove('hidden');}
function closeForm(){formModal.classList.add('hidden');formModalBody.innerHTML='';}
document.getElementById('closeFormModal')?.addEventListener('click',closeForm);formModal?.addEventListener('click',e=>{if(e.target===formModal)closeForm();});

function createUserForm(){return `<span class="eyebrow">ADMINISTRATION</span><h2>Create user</h2><p class="muted form-intro">Create a local account now. A real provider number can be mapped later.</p><form id="createUserForm" class="stack-form"><label>Name<input name="name" required></label><label>Email<input name="email" type="email" required></label><label>Temporary password<input name="password" type="password" minlength="8" required placeholder="At least 8 characters"></label><label>Assigned number placeholder<input name="phone_number" placeholder="Optional, e.g. +1 305 555 0199"></label><button class="btn primary" type="submit">Create user</button></form>`;}
document.getElementById('createUserBtn')?.addEventListener('click',()=>openForm(createUserForm()));

document.addEventListener('submit',async e=>{
  if(e.target.id==='createUserForm'){
    e.preventDefault();const data=Object.fromEntries(new FormData(e.target));const r=await postForm('api/create_user.php',data);toast(r.message,r.ok?'success':'error');if(r.ok)setTimeout(()=>location.reload(),450);
  }
  if(e.target.id==='editUserForm'){
    e.preventDefault();const data=Object.fromEntries(new FormData(e.target));const r=await postForm('api/update_user.php',data);toast(r.message,r.ok?'success':'error');if(r.ok)setTimeout(()=>location.reload(),450);
  }
  if(e.target.id==='addContactForm'){
    e.preventDefault();const fd=new FormData(e.target);const data=Object.fromEntries(fd);if(fd.get('favorite'))data.favorite='1';const r=await postForm('api/add_contact.php',data);toast(r.message,r.ok?'success':'error');if(r.ok)setTimeout(()=>location.reload(),450);
  }
  if(e.target.id==='newMessageForm'){
    e.preventDefault();const data=Object.fromEntries(new FormData(e.target));closeForm();switchView('messages');setConversation(data.phone_number,data.contact_name||data.phone_number,false);document.getElementById('messageInput').focus();
  }
});

document.querySelectorAll('.edit-user-btn').forEach(btn=>btn.addEventListener('click',()=>{
  openForm(`<span class="eyebrow">USER ACCOUNT</span><h2>${escapeHtml(btn.dataset.userName)}</h2><p class="muted form-intro">${escapeHtml(btn.dataset.userEmail)}</p><form id="editUserForm" class="stack-form"><input type="hidden" name="user_id" value="${escapeHtml(btn.dataset.userId)}"><label>Assigned number placeholder<input name="phone_number" value="${escapeHtml(btn.dataset.userPhone||'')}" placeholder="Leave blank for none"></label><label>Status<select name="status"><option value="active" ${btn.dataset.userStatus==='active'?'selected':''}>Active</option><option value="suspended" ${btn.dataset.userStatus==='suspended'?'selected':''}>Suspended</option></select></label><button class="btn primary" type="submit">Save changes</button></form>`);
}));

document.getElementById('addContactBtn')?.addEventListener('click',()=>openForm(`<span class="eyebrow">ADDRESS BOOK</span><h2>Add contact</h2><form id="addContactForm" class="stack-form"><label>Name<input name="name" required></label><label>Phone number<input name="phone_number" required></label><label>Category<select name="category"><option>Personal</option><option>Business</option><option>Other</option></select></label><label class="checkbox modal-check"><input type="checkbox" name="favorite" value="1"> Add to favorites</label><button class="btn primary" type="submit">Save contact</button></form>`));

document.getElementById('newMsg')?.addEventListener('click',()=>openForm(`<span class="eyebrow">MESSAGES</span><h2>New local message</h2><form id="newMessageForm" class="stack-form"><label>Phone number<input name="phone_number" required placeholder="+1 ..."></label><label>Contact name<input name="contact_name" placeholder="Optional"></label><button class="btn primary" type="submit">Open conversation</button></form>`));

document.addEventListener('click',e=>{
  const b=e.target.closest('[data-message-number]');if(b){e.preventDefault();switchView('messages');setConversation(b.dataset.messageNumber,b.dataset.messageName||b.dataset.messageNumber,false);}
});

async function setConversation(phone,name='',load=true){
  document.getElementById('messagePhone').value=phone;document.getElementById('messageContactName').value=name||'';document.getElementById('chatPhone').textContent=phone;document.getElementById('chatName').textContent=name||phone;document.getElementById('chatCallBtn').dataset.callNumber=phone;
  document.querySelectorAll('.conversation-btn').forEach(b=>b.classList.toggle('active',b.dataset.conversationPhone===phone));
  if(!load){document.getElementById('chatMessages').innerHTML='<div class="empty-chat">No saved messages in this conversation yet.</div>';return;}
  const res=await fetch(`api/conversation.php?phone=${encodeURIComponent(phone)}`);const data=await res.json();if(!data.ok){toast(data.message,'error');return;}
  document.getElementById('chatName').textContent=data.name;document.getElementById('messageContactName').value=data.name===phone?'':data.name;
  document.getElementById('chatMessages').innerHTML=data.messages.length?data.messages.map(m=>`<div class="bubble ${m.direction==='outgoing'?'outgoing':'incoming'}">${escapeHtml(m.body)}<span>${escapeHtml(m.time)} · ${escapeHtml(m.status_label)}</span></div>`).join(''):'<div class="empty-chat">No messages yet.</div>';
  document.getElementById('chatMessages').scrollTop=document.getElementById('chatMessages').scrollHeight;
}
document.querySelectorAll('.conversation-btn').forEach(b=>b.addEventListener('click',()=>setConversation(b.dataset.conversationPhone,b.dataset.conversationName,true)));

const messageForm=document.getElementById('messageForm');
messageForm?.addEventListener('submit',async e=>{
  e.preventDefault();const input=document.getElementById('messageInput');const text=input.value.trim();const phone=document.getElementById('messagePhone').value.trim();const name=document.getElementById('messageContactName').value.trim();
  if(!phone){toast('Choose or start a conversation first.','error');return;} if(!text)return;
  const r=await postForm('api/send_message.php',{phone_number:phone,contact_name:name,body:text});if(!r.ok){toast(r.message,'error');return;}
  const box=document.getElementById('chatMessages');box.querySelector('.empty-chat')?.remove();box.insertAdjacentHTML('beforeend',`<div class="bubble outgoing">${escapeHtml(text)}<span>${escapeHtml(r.created_at)} · local simulation</span></div>`);input.value='';box.scrollTop=box.scrollHeight;toast('Message saved locally.');
});

function bindSearch(inputId,selector,getText){const input=document.getElementById(inputId);if(!input)return;input.addEventListener('input',()=>{const q=input.value.toLowerCase().trim();document.querySelectorAll(selector).forEach(el=>{el.style.display=(getText(el).toLowerCase().includes(q)?'':'none');});});}
bindSearch('conversationSearch','.conversation-btn',el=>el.innerText);bindSearch('contactSearch','.searchable-contact',el=>el.innerText);bindSearch('adminSearch','.admin-user-row',el=>el.dataset.userSearch||el.innerText);

document.querySelectorAll('[data-call-filter]').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('[data-call-filter]').forEach(b=>b.classList.toggle('active',b===btn));const f=btn.dataset.callFilter;document.querySelectorAll('.history-row').forEach(r=>r.style.display=(f==='all'||r.dataset.direction===f)?'':'none');}));
