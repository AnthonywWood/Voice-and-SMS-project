<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
$config = app_config();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $root = db(false);
        $dbName = preg_replace('/[^a-zA-Z0-9_]/', '', $config['db']['name']);
        $root->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo = db();

        $schema = [
            "CREATE TABLE IF NOT EXISTS users (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(120) NOT NULL,
                email VARCHAR(190) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                role ENUM('admin','user') NOT NULL DEFAULT 'user',
                status ENUM('active','suspended') NOT NULL DEFAULT 'active',
                phone_number VARCHAR(40) NULL UNIQUE,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS contacts (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                name VARCHAR(120) NOT NULL,
                phone_number VARCHAR(40) NOT NULL,
                category VARCHAR(40) NOT NULL DEFAULT 'Personal',
                favorite TINYINT(1) NOT NULL DEFAULT 0,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_contacts_user (user_id),
                CONSTRAINT fk_contacts_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS calls (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                direction ENUM('incoming','outgoing','missed') NOT NULL,
                phone_number VARCHAR(40) NOT NULL,
                contact_name VARCHAR(120) NULL,
                call_status ENUM('local_simulation','completed','missed','failed') NOT NULL DEFAULT 'local_simulation',
                duration_seconds INT UNSIGNED NOT NULL DEFAULT 0,
                provider_call_id VARCHAR(190) NULL,
                started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_calls_user_started (user_id, started_at),
                CONSTRAINT fk_calls_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS messages (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                direction ENUM('incoming','outgoing') NOT NULL,
                phone_number VARCHAR(40) NOT NULL,
                contact_name VARCHAR(120) NULL,
                body TEXT NOT NULL,
                message_status ENUM('local_simulation','queued','sent','delivered','failed','read') NOT NULL DEFAULT 'local_simulation',
                provider_message_id VARCHAR(190) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_messages_user_phone (user_id, phone_number, created_at),
                CONSTRAINT fk_messages_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS system_logs (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                actor_user_id INT UNSIGNED NULL,
                action VARCHAR(80) NOT NULL,
                target_type VARCHAR(60) NULL,
                target_id BIGINT UNSIGNED NULL,
                details TEXT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_logs_created (created_at),
                CONSTRAINT fk_logs_actor FOREIGN KEY (actor_user_id) REFERENCES users(id) ON DELETE SET NULL
            ) ENGINE=InnoDB"
        ];
        foreach ($schema as $sql) $pdo->exec($sql);

        // Safe seed: only add demo accounts if they do not already exist.
        $seedUsers = [
            ['System Admin', 'admin@example.com', 'Admin123!', 'admin', 'active', null],
            ['Demo User', 'demo@example.com', 'Password123!', 'user', 'active', '+1 (305) 555-0184'],
            ['Andrea Miller', 'andrea@example.com', 'Password123!', 'user', 'active', '+1 (876) 555-3028'],
            ['David Wilson', 'david@example.com', 'Password123!', 'user', 'suspended', null],
        ];
        $find = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $insert = $pdo->prepare('INSERT INTO users (name,email,password_hash,role,status,phone_number) VALUES (?,?,?,?,?,?)');
        foreach ($seedUsers as $u) {
            $find->execute([$u[1]]);
            if (!$find->fetch()) {
                $insert->execute([$u[0], $u[1], password_hash($u[2], PASSWORD_DEFAULT), $u[3], $u[4], $u[5]]);
            }
        }

        $demoId = (int)$pdo->query("SELECT id FROM users WHERE email='demo@example.com'")->fetchColumn();
        $countContacts = $pdo->prepare('SELECT COUNT(*) FROM contacts WHERE user_id=?');
        $countContacts->execute([$demoId]);
        if ((int)$countContacts->fetchColumn() === 0) {
            $c = $pdo->prepare('INSERT INTO contacts (user_id,name,phone_number,category,favorite) VALUES (?,?,?,?,?)');
            $c->execute([$demoId,'John Smith','+1 (305) 555-1102','Personal',1]);
            $c->execute([$demoId,'Andrea Miller','+1 (876) 555-3028','Business',1]);
            $c->execute([$demoId,'David Wilson','+1 (954) 555-6114','Personal',1]);
        }

        $countCalls = $pdo->prepare('SELECT COUNT(*) FROM calls WHERE user_id=?');
        $countCalls->execute([$demoId]);
        if ((int)$countCalls->fetchColumn() === 0) {
            $c = $pdo->prepare('INSERT INTO calls (user_id,direction,phone_number,contact_name,call_status,duration_seconds,started_at) VALUES (?,?,?,?,?,?,?)');
            $c->execute([$demoId,'outgoing','+1 (305) 555-1102','John Smith','local_simulation',494,date('Y-m-d 16:15:00')]);
            $c->execute([$demoId,'missed','+1 (876) 555-9274',null,'missed',0,date('Y-m-d 14:32:00')]);
            $c->execute([$demoId,'incoming','+1 (876) 555-3028','Andrea Miller','local_simulation',221,date('Y-m-d 11:08:00')]);
            $c->execute([$demoId,'outgoing','+1 (954) 555-6114','David Wilson','local_simulation',723,date('Y-m-d 18:42:00', strtotime('-1 day'))]);
        }

        $countMsg = $pdo->prepare('SELECT COUNT(*) FROM messages WHERE user_id=?');
        $countMsg->execute([$demoId]);
        if ((int)$countMsg->fetchColumn() === 0) {
            $m = $pdo->prepare('INSERT INTO messages (user_id,direction,phone_number,contact_name,body,message_status,created_at) VALUES (?,?,?,?,?,?,?)');
            $today = date('Y-m-d');
            $m->execute([$demoId,'incoming','+1 (305) 555-1102','John Smith','Hi, are you available for a quick call?','read',"$today 16:16:00"]);
            $m->execute([$demoId,'outgoing','+1 (305) 555-1102','John Smith','Yes, give me a few minutes.','local_simulation',"$today 16:18:00"]);
            $m->execute([$demoId,'incoming','+1 (305) 555-1102','John Smith',"Okay, I'll call you shortly.",'read',"$today 16:20:00"]);
            $m->execute([$demoId,'incoming','+1 (876) 555-3028','Andrea Miller','Can you send the details?','read',"$today 15:57:00"]);
            $m->execute([$demoId,'incoming','+1 (305) 555-9921',null,'Thank you.','read',"$today 14:13:00"]);
        }

        $message = 'Database and local demo data are ready.';
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Call App Setup</title><link rel="stylesheet" href="assets/style.css"></head>
<body>
<div class="setup-page">
  <div class="setup-card">
    <div class="brand-mark">C</div>
    <div><span class="eyebrow">LOCAL INSTALLER</span><h1>Call App setup</h1><p class="muted">Creates the MariaDB database and starter accounts for local XAMPP testing.</p></div>
    <?php if ($message): ?><div class="notice success"><?=e($message)?></div><?php endif; ?>
    <?php if ($error): ?><div class="notice error"><strong>Setup failed:</strong> <?=e($error)?></div><?php endif; ?>
    <div class="setup-details">
      <p><strong>Database:</strong> <?=e($config['db']['name'])?></p>
      <p><strong>Provider mode:</strong> Local simulation only</p>
      <p><strong>Admin login:</strong> admin@example.com / Admin123!</p>
      <p><strong>User login:</strong> demo@example.com / Password123!</p>
    </div>
    <form method="post"><button class="btn primary full" type="submit">Install / repair database</button></form>
    <a class="btn-link" href="index.php">Go to login →</a>
  </div>
</div>
</body></html>
