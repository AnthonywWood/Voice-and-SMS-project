<?php
require_once __DIR__ . '/../includes/auth.php'; require_once __DIR__ . '/../includes/helpers.php';
$user=require_login(); verify_csrf();
$name=trim($_POST['name']??'');$phone=trim($_POST['phone_number']??'');$category=trim($_POST['category']??'Personal');$favorite=!empty($_POST['favorite'])?1:0;
if(!$name||!$phone) json_response(['ok'=>false,'message'=>'Contact name and phone number are required.'],422);
$stmt=db()->prepare('INSERT INTO contacts(user_id,name,phone_number,category,favorite) VALUES(?,?,?,?,?)');$stmt->execute([$user['id'],$name,$phone,$category?:'Personal',$favorite]);
json_response(['ok'=>true,'message'=>'Contact saved.']);
