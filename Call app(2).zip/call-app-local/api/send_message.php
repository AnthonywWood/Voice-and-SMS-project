<?php
require_once __DIR__ . '/../includes/auth.php'; require_once __DIR__ . '/../includes/helpers.php';
$user=require_login(); verify_csrf();
$phone=trim($_POST['phone_number']??'');$name=trim($_POST['contact_name']??'');$body=trim($_POST['body']??'');
if(!$phone||!$body) json_response(['ok'=>false,'message'=>'Phone number and message are required.'],422);
if(mb_strlen($body)>1600) json_response(['ok'=>false,'message'=>'Local test messages are limited to 1600 characters.'],422);
$stmt=db()->prepare("INSERT INTO messages(user_id,direction,phone_number,contact_name,body,message_status) VALUES(?,'outgoing',?,?,?,'local_simulation')");$stmt->execute([$user['id'],$phone,$name?:null,$body]);
$id=(int)db()->lastInsertId();
json_response(['ok'=>true,'message'=>'Saved locally.','message_id'=>$id,'created_at'=>date('g:i A'),'status'=>'local simulation']);
