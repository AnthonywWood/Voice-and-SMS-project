<?php
require_once __DIR__ . '/../includes/auth.php'; require_once __DIR__ . '/../includes/helpers.php';
$admin=require_admin(); verify_csrf();
if($_SERVER['REQUEST_METHOD']!=='POST') json_response(['ok'=>false,'message'=>'POST required'],405);
$name=trim($_POST['name']??''); $email=strtolower(trim($_POST['email']??'')); $password=$_POST['password']??''; $phone=trim($_POST['phone_number']??'');
if(!$name || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<8) json_response(['ok'=>false,'message'=>'Name, valid email, and password of at least 8 characters are required.'],422);
try{
 $stmt=db()->prepare("INSERT INTO users(name,email,password_hash,role,status,phone_number) VALUES(?,?,?,'user','active',?)");
 $stmt->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT),$phone!==''?$phone:null]);
 $id=(int)db()->lastInsertId();
 $log=db()->prepare('INSERT INTO system_logs(actor_user_id,action,target_type,target_id,details) VALUES(?,?,?,?,?)');$log->execute([$admin['id'],'create_user','user',$id,'Created '.$email]);
 json_response(['ok'=>true,'message'=>'User created. Reloading…']);
}catch(PDOException $e){json_response(['ok'=>false,'message'=>$e->getCode()==='23000'?'Email or phone number is already in use.':'Could not create user.'],422);}
