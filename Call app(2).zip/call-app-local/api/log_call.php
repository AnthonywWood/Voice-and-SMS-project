<?php
require_once __DIR__ . '/../includes/auth.php'; require_once __DIR__ . '/../includes/helpers.php';
$user=require_login(); verify_csrf();
$phone=trim($_POST['phone_number']??'');$name=trim($_POST['contact_name']??'');$duration=max(0,(int)($_POST['duration_seconds']??0));
if(!$phone) json_response(['ok'=>false,'message'=>'Phone number required.'],422);
$stmt=db()->prepare("INSERT INTO calls(user_id,direction,phone_number,contact_name,call_status,duration_seconds,started_at) VALUES(?,'outgoing',?,?, 'local_simulation',?,NOW())");$stmt->execute([$user['id'],$phone,$name?:null,$duration]);
json_response(['ok'=>true,'message'=>'Call saved as local simulation.']);
