<?php
require_once __DIR__ . '/../includes/auth.php'; require_once __DIR__ . '/../includes/helpers.php';
$admin=require_admin(); verify_csrf();
$id=(int)($_POST['user_id']??0); $phone=trim($_POST['phone_number']??''); $status=$_POST['status']??'';
if(!$id || !in_array($status,['active','suspended'],true)) json_response(['ok'=>false,'message'=>'Invalid user update.'],422);
if($id===(int)$admin['id']) json_response(['ok'=>false,'message'=>'Use a separate account-management flow to change the current admin.'],422);
try{
 $stmt=db()->prepare('UPDATE users SET phone_number=?,status=? WHERE id=? AND role=?');$stmt->execute([$phone!==''?$phone:null,$status,$id,'user']);
 $log=db()->prepare('INSERT INTO system_logs(actor_user_id,action,target_type,target_id,details) VALUES(?,?,?,?,?)');$log->execute([$admin['id'],'update_user','user',$id,'Status='.$status.'; phone='.$phone]);
 json_response(['ok'=>true,'message'=>'User updated.']);
}catch(PDOException $e){json_response(['ok'=>false,'message'=>$e->getCode()==='23000'?'That phone number is already assigned.':'Could not update user.'],422);}
