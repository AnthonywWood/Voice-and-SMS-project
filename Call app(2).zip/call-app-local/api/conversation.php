<?php
require_once __DIR__ . '/../includes/auth.php'; require_once __DIR__ . '/../includes/helpers.php';
$user=require_login();
$phone=trim($_GET['phone']??''); if(!$phone) json_response(['ok'=>false,'message'=>'Phone number required.'],422);
$stmt=db()->prepare('SELECT direction,phone_number,contact_name,body,message_status,created_at FROM messages WHERE user_id=? AND phone_number=? ORDER BY created_at ASC LIMIT 200');$stmt->execute([$user['id'],$phone]);$messages=$stmt->fetchAll();
$name='';$stmt=db()->prepare('SELECT name FROM contacts WHERE user_id=? AND phone_number=? ORDER BY id DESC LIMIT 1');$stmt->execute([$user['id'],$phone]);$name=(string)($stmt->fetchColumn()?:'');
if(!$name&&$messages){$last=$messages[count($messages)-1];$name=$last['contact_name']?:$phone;} if(!$name)$name=$phone;
foreach($messages as &$m){$m['time']=date('g:i A',strtotime($m['created_at']));$m['status_label']=str_replace('_',' ',$m['message_status']);}
json_response(['ok'=>true,'phone'=>$phone,'name'=>$name,'messages'=>$messages]);
