<?php
function e(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function initials(string $name): string {
    $parts = preg_split('/\s+/', trim($name));
    $letters = '';
    foreach (array_slice($parts, 0, 2) as $part) {
        if ($part !== '') $letters .= strtoupper(substr($part, 0, 1));
    }
    return $letters ?: 'U';
}

function phone_display(?string $number): string {
    return $number ?: 'Not assigned';
}

function format_duration(int $seconds): string {
    if ($seconds <= 0) return '0s';
    $m = intdiv($seconds, 60);
    $s = $seconds % 60;
    return $m ? $m . 'm ' . str_pad((string)$s, 2, '0', STR_PAD_LEFT) . 's' : $s . 's';
}

function relative_day(string $date): string {
    $ts = strtotime($date);
    if (date('Y-m-d', $ts) === date('Y-m-d')) return 'Today';
    if (date('Y-m-d', $ts) === date('Y-m-d', strtotime('-1 day'))) return 'Yesterday';
    return date('M j', $ts);
}

function json_response(array $data, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
