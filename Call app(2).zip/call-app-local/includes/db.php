<?php
function app_config(): array {
    static $config;
    if (!$config) {
        $config = require __DIR__ . '/../config.php';
    }
    return $config;
}

function db(bool $withDatabase = true): PDO {
    static $pdo = null;
    if ($withDatabase && $pdo instanceof PDO) {
        return $pdo;
    }

    $cfg = app_config()['db'];
    $dsn = 'mysql:host=' . $cfg['host'] . ';port=' . $cfg['port'] . ';charset=' . $cfg['charset'];
    if ($withDatabase) {
        $dsn .= ';dbname=' . $cfg['name'];
    }
    $conn = new PDO($dsn, $cfg['user'], $cfg['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    if ($withDatabase) {
        $pdo = $conn;
    }
    return $conn;
}
