<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
$user = require_login();
$pdo = db();
$uid = (int)$user['id'];
$isAdmin = $user['role'] === 'admin';

$stmt = $pdo->prepare("SELECT COUNT(*) FROM calls WHERE user_id=? AND DATE(started_at)=CURDATE()"); $stmt->execute([$uid]); $callsToday=(int)$stmt->fetchColumn();
$stmt = $pdo->prepare("SELECT COUNT(*) FROM messages WHERE user_id=? AND DATE(created_at)=CURDATE()"); $stmt->execute([$uid]); $messagesToday=(int)$stmt->fetchColumn();
$stmt = $pdo->prepare("SELECT COALESCE(SUM(duration_seconds),0) FROM calls WHERE user_id=? AND DATE(started_at)=CURDATE()"); $stmt->execute([$uid]); $talkSeconds=(int)$stmt->fetchColumn();
$stmt = $pdo->prepare("SELECT COUNT(*) FROM contacts WHERE user_id=?"); $stmt->execute([$uid]); $contactCount=(int)$stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT * FROM calls WHERE user_id=? ORDER BY started_at DESC LIMIT 12"); $stmt->execute([$uid]); $calls=$stmt->fetchAll();
$stmt = $pdo->prepare("SELECT * FROM contacts WHERE user_id=? ORDER BY favorite DESC,name ASC"); $stmt->execute([$uid]); $contacts=$stmt->fetchAll();

$stmt = $pdo->prepare("SELECT m.* FROM messages m JOIN (SELECT phone_number, MAX(id) AS max_id FROM messages WHERE user_id=? GROUP BY phone_number) x ON x.max_id=m.id ORDER BY m.created_at DESC LIMIT 20");
$stmt->execute([$uid]); $conversations=$stmt->fetchAll();
$selectedPhone = $_GET['phone'] ?? ($conversations[0]['phone_number'] ?? ($contacts[0]['phone_number'] ?? ''));
$selectedName = '';
$chatMessages=[];
if ($selectedPhone !== '') {
    $stmt=$pdo->prepare("SELECT * FROM messages WHERE user_id=? AND phone_number=? ORDER BY created_at ASC LIMIT 200"); $stmt->execute([$uid,$selectedPhone]); $chatMessages=$stmt->fetchAll();
    foreach ($contacts as $c) if ($c['phone_number']===$selectedPhone) {$selectedName=$c['name'];break;}
    if (!$selectedName && $chatMessages) $selectedName=$chatMessages[count($chatMessages)-1]['contact_name'] ?: $selectedPhone;
}

$adminUsers=[];$adminStats=['users'=>0,'active'=>0,'suspended'=>0,'assigned'=>0,'calls'=>0,'messages'=>0];
if ($isAdmin) {
    $adminUsers=$pdo->query("SELECT id,name,email,role,status,phone_number,created_at FROM users ORDER BY id ASC")->fetchAll();
    $adminStats['users']=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
    $adminStats['active']=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='user' AND status='active'")->fetchColumn();
    $adminStats['suspended']=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='user' AND status='suspended'")->fetchColumn();
    $adminStats['assigned']=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='user' AND phone_number IS NOT NULL AND phone_number<>''")->fetchColumn();
    $adminStats['calls']=(int)$pdo->query("SELECT COUNT(*) FROM calls WHERE DATE(started_at)=CURDATE()")->fetchColumn();
    $adminStats['messages']=(int)$pdo->query("SELECT COUNT(*) FROM messages WHERE DATE(created_at)=CURDATE()")->fetchColumn();
}

function call_icon(array $call): string { return $call['direction']==='outgoing'?'↗':($call['direction']==='missed'?'↙':'↙'); }
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Call App</title><link rel="stylesheet" href="assets/style.css"></head>
<body>
<div id="appShell" class="app-shell">
  <aside class="sidebar">
    <div class="sidebar-brand"><div class="brand-mark small">C</div><div><strong>Call App</strong><span><?=e(ucfirst(app_config()['provider_mode']))?> workspace</span></div></div>
    <nav class="nav-menu">
      <button class="nav-item active" data-view="home"><span>◫</span> Home</button>
      <button class="nav-item" data-view="dialer"><span>⌨</span> Dialer</button>
      <button class="nav-item" data-view="messages"><span>✉</span> Messages</button>
      <button class="nav-item" data-view="contacts"><span>◎</span> Contacts</button>
      <button class="nav-item" data-view="history"><span>↺</span> Call history</button>
      <?php if ($isAdmin): ?><button class="nav-item" data-view="admin"><span>⚙</span> Admin</button><?php endif; ?>
    </nav>
    <div class="sidebar-bottom"><div class="user-card"><div class="avatar"><?=e(initials($user['name']))?></div><div><strong><?=e($user['name'])?></strong><span><?=e(phone_display($user['phone_number']))?></span></div></div><a class="btn ghost full logout-link" href="logout.php">Log out</a></div>
  </aside>

  <main class="main">
    <header class="topbar"><div><span class="eyebrow">LOCAL DEVELOPMENT</span><h2 id="pageTitle">Phone dashboard</h2></div><div class="top-actions"><span class="line-status local"><i></i> Provider not connected</span><div class="avatar top-avatar"><?=e(initials($user['name']))?></div></div></header>

    <div class="notice info provider-banner"><strong>Local simulation mode:</strong> calls and messages are saved in MariaDB but are not sent to a telephone network yet.</div>

    <section id="home" class="view active-view">
      <div class="number-card"><div><span class="eyebrow light">YOUR ASSIGNED NUMBER</span><h3><?=e(phone_display($user['phone_number']))?></h3><p><?= $user['phone_number'] ? 'Stored on your account and ready for future provider mapping.' : 'An administrator can assign a number placeholder.' ?></p></div><div class="number-actions"><button class="btn white" data-jump="dialer">Make a call</button><button class="btn translucent" data-jump="messages">New message</button></div></div>
      <div class="stats-grid"><article class="stat"><span>Calls today</span><strong><?=$callsToday?></strong><small>Stored locally</small></article><article class="stat"><span>Messages today</span><strong><?=$messagesToday?></strong><small>Stored locally</small></article><article class="stat"><span>Talk time</span><strong><?=floor($talkSeconds/60)?>m</strong><small>Simulated records</small></article><article class="stat"><span>Contacts</span><strong><?=$contactCount?></strong><small>Saved to account</small></article></div>
      <div class="content-grid">
        <article class="panel large-panel"><div class="panel-head"><div><span class="eyebrow">RECENT ACTIVITY</span><h3>Recent calls</h3></div><button class="text-btn" data-jump="history">View all</button></div><div class="call-list">
        <?php if (!$calls): ?><p class="empty-state">No call records yet.</p><?php endif; ?>
        <?php foreach(array_slice($calls,0,3) as $c): ?><div class="call-row"><div class="avatar"><?=e(initials($c['contact_name'] ?: $c['phone_number']))?></div><div class="grow"><strong><?=e($c['contact_name'] ?: $c['phone_number'])?></strong><span class="<?=$c['direction']==='missed'?'missed':''?>"><?=call_icon($c)?> <?=e(ucfirst($c['direction']))?><?= $c['duration_seconds'] ? ' · '.e(format_duration((int)$c['duration_seconds'])) : '' ?></span></div><div class="right"><strong><?=e(date('g:i A',strtotime($c['started_at'])))?></strong><span><?=e(relative_day($c['started_at']))?></span></div><button class="mini-call" data-call-number="<?=e($c['phone_number'])?>">☎</button></div><?php endforeach; ?>
        </div></article>
        <article class="panel"><div class="panel-head"><div><span class="eyebrow">MESSAGES</span><h3>Recent conversations</h3></div><button class="text-btn" data-jump="messages">Open inbox</button></div>
        <?php if (!$conversations): ?><p class="empty-state">No messages yet.</p><?php endif; ?>
        <?php foreach(array_slice($conversations,0,3) as $m): ?><div class="message-preview"><div class="avatar"><?=e(initials($m['contact_name'] ?: $m['phone_number']))?></div><div><strong><?=e($m['contact_name'] ?: $m['phone_number'])?></strong><p><?=e(mb_strimwidth($m['body'],0,48,'…'))?></p><span><?=e(date('g:i A',strtotime($m['created_at'])))?></span></div></div><?php endforeach; ?>
        </article>
      </div>
    </section>

    <section id="dialer" class="view"><div class="dialer-wrap"><article class="panel dialer-card"><span class="eyebrow">DIALER</span><div class="dial-number" id="dialNumber">Enter number</div><div class="dial-pad">
      <?php foreach([['1',''],['2','ABC'],['3','DEF'],['4','GHI'],['5','JKL'],['6','MNO'],['7','PQRS'],['8','TUV'],['9','WXYZ'],['*',''],['0','+'],['#','']] as $d): ?><button data-digit="<?=e($d[0])?>"><?=e($d[0])?><small><?=e($d[1]?:' ')?></small></button><?php endforeach; ?>
      </div><div class="dial-actions"><button id="backspace" class="round-btn neutral">⌫</button><button id="callBtn" class="round-btn call">☎</button><button id="clearDial" class="round-btn neutral">×</button></div><p class="center muted">Calls are recorded as local simulations until a provider is connected.</p></article>
      <article class="panel quick-contacts"><div class="panel-head"><div><span class="eyebrow">QUICK CALL</span><h3>Favorites</h3></div></div><?php foreach(array_slice(array_values(array_filter($contacts,fn($c)=>(int)$c['favorite']===1)),0,5) as $c): ?><div class="favorite"><div class="avatar"><?=e(initials($c['name']))?></div><div class="grow"><strong><?=e($c['name'])?></strong><span><?=e($c['phone_number'])?></span></div><button class="mini-call" data-call-number="<?=e($c['phone_number'])?>">☎</button></div><?php endforeach; ?><?php if (!$contacts): ?><p class="empty-state">Add contacts to see quick-call options.</p><?php endif; ?></article></div></section>

    <section id="messages" class="view"><div class="messages-layout"><article class="panel conversations"><div class="panel-head"><div><span class="eyebrow">INBOX</span><h3>Messages</h3></div><button id="newMsg" class="btn small primary">+ New</button></div><input id="conversationSearch" class="search" placeholder="Search conversations..."><div id="conversationList">
      <?php foreach($conversations as $m): ?><button class="conversation conversation-btn <?=$m['phone_number']===$selectedPhone?'active':''?>" data-conversation-phone="<?=e($m['phone_number'])?>" data-conversation-name="<?=e($m['contact_name'] ?: $m['phone_number'])?>"><div class="avatar"><?=e(initials($m['contact_name'] ?: $m['phone_number']))?></div><div class="grow"><div><strong><?=e($m['contact_name'] ?: $m['phone_number'])?></strong><span><?=e(date('g:i A',strtotime($m['created_at'])))?></span></div><p><?=e($m['body'])?></p></div></button><?php endforeach; ?>
      <?php if (!$conversations): ?><p class="empty-state">No conversations yet. Click New to start a local message thread.</p><?php endif; ?></div></article>
      <article class="panel chat-panel"><div class="chat-head"><div class="avatar" id="chatAvatar"><?=e(initials($selectedName ?: $selectedPhone ?: 'New'))?></div><div class="grow"><strong id="chatName"><?=e($selectedName ?: ($selectedPhone ?: 'New conversation'))?></strong><span id="chatPhone"><?=e($selectedPhone)?></span></div><button class="mini-call" id="chatCallBtn" data-call-number="<?=e($selectedPhone)?>">☎ Call</button></div><div id="chatMessages" class="chat-messages">
      <?php foreach($chatMessages as $m): ?><div class="bubble <?=$m['direction']==='outgoing'?'outgoing':'incoming'?>"><?=e($m['body'])?><span><?=e(date('g:i A',strtotime($m['created_at'])))?> · <?=e(str_replace('_',' ',$m['message_status']))?></span></div><?php endforeach; ?>
      <?php if (!$selectedPhone): ?><div class="empty-chat">Choose a conversation or click New.</div><?php endif; ?></div>
      <form id="messageForm" class="message-composer"><button type="button" disabled>＋</button><input type="hidden" id="messagePhone" value="<?=e($selectedPhone)?>"><input type="hidden" id="messageContactName" value="<?=e($selectedName)?>"><input id="messageInput" placeholder="Type a local message..." autocomplete="off"><button class="send-btn" type="submit">Save</button></form></article></div></section>

    <section id="contacts" class="view"><article class="panel"><div class="panel-head"><div><span class="eyebrow">ADDRESS BOOK</span><h3>Contacts</h3></div><button id="addContactBtn" class="btn small primary">+ Add contact</button></div><input id="contactSearch" class="search" placeholder="Search name or number..."><div class="contact-table"><div class="table-row table-head"><span>Name</span><span>Phone number</span><span>Category</span><span></span></div>
      <?php foreach($contacts as $c): ?><div class="table-row searchable-contact"><div class="person"><div class="avatar"><?=e(initials($c['name']))?></div><div><strong><?=e($c['name'])?></strong><span><?=$c['favorite']?'Favorite':'Contact'?></span></div></div><span><?=e($c['phone_number'])?></span><span><?=e($c['category'])?></span><div class="row-actions"><button data-message-number="<?=e($c['phone_number'])?>" data-message-name="<?=e($c['name'])?>">✉</button><button data-call-number="<?=e($c['phone_number'])?>">☎</button></div></div><?php endforeach; ?>
      <?php if(!$contacts):?><p class="empty-state">No contacts saved yet.</p><?php endif;?></div></article></section>

    <section id="history" class="view"><article class="panel"><div class="panel-head"><div><span class="eyebrow">ACTIVITY</span><h3>Call history</h3></div><div class="filter-pills"><button class="active" data-call-filter="all">All</button><button data-call-filter="incoming">Incoming</button><button data-call-filter="outgoing">Outgoing</button><button data-call-filter="missed">Missed</button></div></div><div class="call-list extended" id="historyList">
      <?php foreach($calls as $c): ?><div class="call-row history-row" data-direction="<?=e($c['direction'])?>"><div class="avatar"><?=e(initials($c['contact_name'] ?: $c['phone_number']))?></div><div class="grow"><strong><?=e($c['contact_name'] ?: $c['phone_number'])?></strong><span class="<?=$c['direction']==='missed'?'missed':''?>"><?=call_icon($c)?> <?=e(ucfirst($c['direction']))?><?= $c['duration_seconds']?' · '.e(format_duration((int)$c['duration_seconds'])):'' ?></span></div><div class="right"><strong><?=e(date('g:i A',strtotime($c['started_at'])))?></strong><span><?=e(relative_day($c['started_at']))?></span></div><button class="mini-call" data-call-number="<?=e($c['phone_number'])?>">☎</button></div><?php endforeach; ?>
      <?php if(!$calls):?><p class="empty-state">No call history yet.</p><?php endif;?></div></article></section>

    <?php if($isAdmin): ?><section id="admin" class="view"><div class="admin-head panel"><div><span class="eyebrow">ADMINISTRATION</span><h3>System overview</h3><p class="muted">Create users, assign number placeholders, and suspend/reactivate accounts.</p></div><button id="createUserBtn" class="btn primary">+ Create user</button></div><div class="stats-grid admin-stats"><article class="stat"><span>Total users</span><strong><?=$adminStats['users']?></strong><small><?=$adminStats['active']?> active · <?=$adminStats['suspended']?> suspended</small></article><article class="stat"><span>Assigned numbers</span><strong><?=$adminStats['assigned']?></strong><small>Provider mapping comes later</small></article><article class="stat"><span>Calls today</span><strong><?=$adminStats['calls']?></strong><small>Across local records</small></article><article class="stat"><span>SMS today</span><strong><?=$adminStats['messages']?></strong><small>Across local records</small></article></div><article class="panel"><div class="panel-head"><div><span class="eyebrow">USERS</span><h3>User accounts</h3></div><input id="adminSearch" class="search compact" placeholder="Search users..."></div><div class="admin-table"><div class="table-row table-head"><span>User</span><span>Assigned number</span><span>Status</span><span>Role</span><span></span></div>
      <?php foreach($adminUsers as $u): ?><div class="table-row admin-user-row" data-user-search="<?=e(strtolower($u['name'].' '.$u['email'].' '.($u['phone_number']??'')))?>"><div class="person"><div class="avatar"><?=e(initials($u['name']))?></div><div><strong><?=e($u['name'])?></strong><span><?=e($u['email'])?></span></div></div><span><?=e(phone_display($u['phone_number']))?></span><span><b class="status <?=e($u['status'])?>"><?=e(ucfirst($u['status']))?></b></span><span><?=e(ucfirst($u['role']))?></span><?php if($u['id']!=$uid):?><button class="more-btn edit-user-btn" data-user-id="<?=$u['id']?>" data-user-name="<?=e($u['name'])?>" data-user-email="<?=e($u['email'])?>" data-user-phone="<?=e($u['phone_number']??'')?>" data-user-status="<?=e($u['status'])?>">Edit</button><?php else:?><span class="muted">You</span><?php endif;?></div><?php endforeach; ?>
      </div></article></section><?php endif; ?>
  </main>
</div>

<div id="callModal" class="modal hidden"><div class="call-modal-card"><button class="modal-close" id="closeCall">×</button><div class="avatar call-avatar">☎</div><span class="eyebrow light">LOCAL SIMULATED CALL</span><h2 id="callingNumber">Number</h2><p id="callStatusText">Calling...</p><div class="live-wave"><i></i><i></i><i></i><i></i><i></i></div><div class="call-controls"><button>🎙<small>Mute</small></button><button>⌨<small>Keypad</small></button><button>🔊<small>Speaker</small></button></div><button id="endCall" class="end-call">☎</button></div></div>

<div id="formModal" class="modal hidden"><div class="form-modal-card"><button class="modal-close dark" id="closeFormModal">×</button><div id="formModalBody"></div></div></div>

<script>
window.APP = {csrf: <?=json_encode(csrf_token())?>, role: <?=json_encode($user['role'])?>, userPhone: <?=json_encode($user['phone_number'])?>};
</script>
<script src="assets/app.js"></script>
</body></html>
