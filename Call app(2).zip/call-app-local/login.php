<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
try {
    verify_csrf();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $stmt = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if (!$user || !password_verify($password, $user['password_hash'])) {
        header('Location: index.php?error=' . urlencode('Invalid email or password.'));
        exit;
    }
    if ($user['status'] !== 'active') {
        header('Location: index.php?error=' . urlencode('This account is suspended. Please contact the administrator.'));
        exit;
    }
    login_user((int)$user['id']);
    $log = db()->prepare('INSERT INTO system_logs (actor_user_id,action,target_type,target_id,details) VALUES (?,?,?,?,?)');
    $log->execute([$user['id'],'login','user',$user['id'],'User signed in']);
    header('Location: app.php');
} catch (Throwable $e) {
    header('Location: index.php?error=' . urlencode('Database is not ready. Open setup.php first.'));
}
