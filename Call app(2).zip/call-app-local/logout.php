<?php
require_once __DIR__ . '/includes/auth.php';
$user = current_user();
if ($user) {
    try {
        $log = db()->prepare('INSERT INTO system_logs (actor_user_id,action,target_type,target_id,details) VALUES (?,?,?,?,?)');
        $log->execute([$user['id'],'logout','user',$user['id'],'User signed out']);
    } catch (Throwable $e) {}
}
logout_user();
header('Location: index.php');
