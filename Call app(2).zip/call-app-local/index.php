<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
if (current_user()) {
    header('Location: app.php');
    exit;
}
$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Call App Login</title><link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="login-screen">
  <div class="login-panel">
    <div class="brand-mark">C</div>
    <div><span class="eyebrow">COMMUNICATION PLATFORM</span><h1>Welcome back</h1><p class="muted">Sign in to manage calls, messages, and contacts.</p></div>
    <?php if ($error): ?><div class="notice error"><?=e($error)?></div><?php endif; ?>
    <form action="login.php" method="post" class="login-form">
      <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
      <label>Email<input type="email" name="email" value="demo@example.com" autocomplete="username" required></label>
      <label>Password<input type="password" name="password" value="Password123!" autocomplete="current-password" required></label>
      <div class="form-row"><label class="checkbox"><input type="checkbox" name="remember" value="1"> Remember me</label><a href="#" onclick="return false;">Forgot password?</a></div>
      <button class="btn primary full" type="submit">Sign in</button>
    </form>
    <p class="demo-note">Local development mode — calls and SMS are stored as simulations until a provider is connected.</p>
  </div>
  <div class="login-visual">
    <div class="visual-card"><span class="status-dot"></span><span>Local system online</span></div>
    <div class="visual-number">Provider connection: not configured</div>
    <h2>One place for calls and messages.</h2>
    <p>The approved interface is now backed by PHP sessions and MariaDB, ready for provider integration later.</p>
  </div>
</div>
</body></html>
