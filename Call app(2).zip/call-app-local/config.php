<?php
return [
    'app_name' => 'Call App',
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'call_app',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4',
    ],
    // Keep this in "local" until a telecom provider is selected.
    'provider_mode' => 'local',
];
