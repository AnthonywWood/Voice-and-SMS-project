CALL APP - PHP + MARIADB LOCAL BUILD
====================================

This build keeps the approved Call App design and adds the real local backend foundation.
It does NOT connect to a telecom provider yet, so it cannot place real PSTN calls or send real SMS.
Calls and messages are stored in MariaDB as LOCAL SIMULATIONS.

WHAT IS NOW WORKING
- PHP session login/logout
- MariaDB database
- Admin and regular user roles
- Admin creates user accounts
- Admin assigns/removes a phone-number placeholder
- Admin suspends/reactivates user accounts
- Suspended users cannot sign in
- Per-user contacts stored in database
- Add contacts and favorites
- Per-user message history stored in database
- Start conversations and save outgoing local messages
- Per-user call history stored in database
- Dialer and quick-call buttons log local simulated calls
- Dashboard statistics come from database
- Call-history filtering
- Search contacts, conversations, and admin users
- CSRF protection on write actions
- Prepared SQL statements
- Passwords stored using password_hash(), not plain text

XAMPP SETUP
1. Unzip the folder named call-app-local.
2. Copy call-app-local into:
   C:\xampp\htdocs\
3. Start Apache and MySQL in XAMPP.
4. Open:
   http://localhost/call-app-local/setup.php
5. Click "Install / repair database".
6. Click "Go to login".

TEST LOGINS
Admin:
  Email: admin@example.com
  Password: Admin123!

Regular user:
  Email: demo@example.com
  Password: Password123!

DATABASE
Default database name: call_app
Default XAMPP credentials in config.php:
  host: 127.0.0.1
  port: 3306
  user: root
  password: blank

If your MariaDB credentials differ, edit config.php before opening setup.php.

IMPORTANT PROVIDER NOTE
config.php has provider_mode set to "local".
Leave it that way until we select and configure Twilio, Telnyx, Plivo, or another provider.
No provider API keys are needed for this version.

NEXT PHASE
After you inspect and approve this local backend version, the next phase is provider integration for:
- buying/assigning real numbers
- outbound SMS
- inbound SMS webhooks
- outbound voice calls
- inbound call routing
- delivery/call status webhooks
